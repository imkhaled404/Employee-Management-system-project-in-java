
package employee_payroll;

public class Emp {
    public static int empId;
    public static String empName;
}
